package test;

import java.sql.Connection;

import model.ReadData;
import model.vo.MemberVo;
import util.SQLConnect;

public class Test {

	
	public static void main(String[] args) {
		
		/*ReadData readData = new ReadData();
		MemberVo memberVo = new MemberVo();
			
		memberVo.setId("A123456789");
		memberVo.setPhone("0900000000");
		memberVo.setName("ccc");
		memberVo.setAddress("aaa");
		memberVo.setNote("aaa");
		
		MemberVo member = readData.select(memberVo);
		
		System.out.print("member.getid() = " + member.getId());*/
		
		SQLConnect conn = new SQLConnect();
		Connection dbcon = conn.getConnection();
		System.out.println(dbcon);
	}
}
