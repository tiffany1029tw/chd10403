package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.MemberVo;
import model.ReadData;

/**
 * Servlet implementation class GetParam
 */
@WebServlet("/GetParam")
public class GetParam extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		this.getParam(request, response);
		
	}
	
	public String getParam(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("id");
		String phone = request.getParameter("phone");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String note = request.getParameter("note");
		
		System.out.println("id :"+ id);
		out.println(id);
		
		System.out.println("name :"+ name);
		out.println(name);
		
		System.out.println("phone :"+ phone);
		out.println(phone);
		
		System.out.println("address :"+ address);
		out.println(address);
		
		System.out.println("note :"+ note);
		out.println(note);
		
		if(button.equals("查詢")) {
			//呼叫查詢的方法
			ReadData readData = new ReadData();
			MemberVo member = readData.select(id);
			
		}else if(button.equals("新增")) {
			//呼叫新增的方法
			
		}else if(button.equals("修改")) {
			//呼叫修改的方法
			
		}else if(button.equals("刪除")) {
			//呼叫刪除的方法
			
		};
		
		return null;
		
	}

}