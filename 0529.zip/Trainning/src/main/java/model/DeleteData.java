package model ;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.vo.MemberVo;
import util.SQLConnect;

public class DeleteData {

	public MemberVo delete(MemberVo memberVo) {
		
		MemberVo member = new MemberVo();
		SQLConnect conn = new SQLConnect();
		Connection dbcon = conn.getConnection(); 
		
		try {
			
			// 建立SQL指令對象
			PreparedStatement ps = dbcon.prepareStatement("DELETE FROM dbo.table_3 WHERE id = ?");
			ps.setString(1, memberVo.getId());
		    ps.executeUpdate(); //執行
		    
		    System.out.println("資料刪除成功");
			
			//關閉物件連接
		    ps.close();
			
			//關閉資料庫連接
			dbcon.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
		return member;
		
	}
	
}