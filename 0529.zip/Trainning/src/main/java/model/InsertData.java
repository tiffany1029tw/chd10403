package model ;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.vo.MemberVo;
import util.SQLConnect;

public class InsertData {

	public MemberVo insert(MemberVo memberVo) {
		
		MemberVo member = new MemberVo();
		SQLConnect conn = new SQLConnect();
		Connection dbcon = conn.getConnection();
		
		try {
			
			// 建立SQL指令對象
			PreparedStatement ps = dbcon.prepareStatement("INSERT INTO dbo.table_3 VALUES(?, ?, ?, ?, ?)");
			
			ps.setString(1, memberVo.getId());
			ps.setString(2, memberVo.getPhone());
			ps.setString(3, memberVo.getName());
			ps.setString(4, memberVo.getAddress());
			ps.setString(5, memberVo.getNote());
	
			ResultSet rs = ps.executeQuery();
		    System.out.println("資料新增成功");
			
			//關閉物件連接
		    ps.close();
			
			//關閉資料庫連接
			dbcon.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
		return member;
		
	}
	
}