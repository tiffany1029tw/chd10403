package model ;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.vo.MemberVo;
import util.SQLConnect;

public class UpdateData {

	public MemberVo update(MemberVo memberVo) {
		
		MemberVo member = new MemberVo();
		SQLConnect conn = new SQLConnect();
		Connection dbcon = conn.getConnection();
		
		try {
			
			// 建立SQL指令對象
			PreparedStatement ps = dbcon.prepareStatement("UPDATE dbo.table_3 SET id=?, phone=?, name=?, address=?, note=? WHERE id = ?");
			
			ps.setString(1, memberVo.getId());
			ps.setString(2, memberVo.getPhone());
			ps.setString(3, memberVo.getName());
			ps.setString(4, memberVo.getAddress());
			ps.setString(5, memberVo.getNote());
		    
		    ps.executeUpdate(); //執行
		    System.out.println("資料修改成功");
			
			//關閉物件連接
		    ps.close();
			
			//關閉資料庫連接
			dbcon.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
		return member;
		
	}
	
}