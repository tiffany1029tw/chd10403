package test;

import java.sql.Connection;

import model.DeleteData;
import model.InsertData;
import model.ReadData;
import model.UpdateData;
import model.vo.MemberVo;
import util.SQLConnect;

public class Test {

	
	public static void main(String[] args) {
		
		ReadData readData = new ReadData();
		InsertData insertData = new InsertData();
		UpdateData updateData = new UpdateData();
		DeleteData deleteData = new DeleteData();
		MemberVo memberVo = new MemberVo();
		
		SQLConnect conn = new SQLConnect();
		Connection dbcon = conn.getConnection();	
		
		memberVo.setId("A225377382");
		memberVo.setPhone("0938187712");
		memberVo.setName("江小姐");
		memberVo.setAddress("汐止");
		memberVo.setNote("貓咪");
		
		//MemberVo member = readData.select(memberVo);
		MemberVo member = insertData.insert(memberVo);
		//MemberVo member = updateData.update(memberVo);
		//MemberVo member = deleteData.delete(memberVo);
		
	}
}
