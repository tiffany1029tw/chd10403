package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLConnect {
	
	public Connection getConnection() {
		
		String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver"; 
		String dburl = "jdbc:sqlserver://172.16.45.213:1433;DatabaseName=kk_testDB;encrypt=true;trustServerCertificate=true"; //資料庫名稱
		String userName = "sqlap";//帳號
		String userPwd = "Ubot@1234";//密碼
		Connection dbcon = null;
		
		try {
			
			Class.forName(driverName); //載入驅動程式
			System.out.println("連線成功");
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
			System.out.println("驅動程式載入失敗");
		}
	
		try {
			
			dbcon = DriverManager.getConnection(dburl,userName,userPwd); //載入資料庫
			System.out.println("資料庫連線成功");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			System.out.println("資料庫連線失敗");
			
		}
		
		return dbcon;
	}
}