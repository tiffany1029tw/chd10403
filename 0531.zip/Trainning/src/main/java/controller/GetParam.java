package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.vo.MemberVo;
import model.ReadData;
import model.InsertData;
import model.UpdateData;
import model.DeleteData;

/**
 * Servlet implementation class GetParam
 */
@WebServlet("/GetParam")
public class GetParam extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("UTF-8"); //解決中文亂碼
		this.getParam(request, response);
		
	}
	
	public String getParam(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("id");
		String phone = request.getParameter("phone");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String note = request.getParameter("note");
		
//		System.out.println("id :"+ id);
		out.println(id);
//		
//		System.out.println("name :"+ name);
		out.println(name);
//		
//		System.out.println("phone :"+ phone);
		out.println(phone);
//		
//		System.out.println("address :"+ address);
		out.println(address);
//		
//		System.out.println("note :"+ note);
		out.println(note);
		
		String readBtn = request.getParameter("readBtn");
		String insertBtn = request.getParameter("insertBtn");
		String updateBtn = request.getParameter("updateBtn");
		String deleteBtn = request.getParameter("deleteBtn");
		String listBtn = request.getParameter("listBtn");
		
		MemberVo memberVo = new MemberVo();
		
		if("查詢".equals(readBtn)) { //呼叫查詢的方法
			ReadData readData = new ReadData();
			MemberVo member = readData.select(memberVo);
			System.out.println("member :"+ member);
			
		}else if("新增".equals(insertBtn)) { //呼叫新增的方法
			InsertData insertData = new InsertData();
			MemberVo member = insertData.insert(memberVo);
			System.out.println("member :"+ member);
						
		}else if("修改".equals(updateBtn)) { //呼叫修改的方法
			UpdateData updateData = new UpdateData();
			MemberVo member = updateData.update(memberVo);
			System.out.println("member :"+ member);
		
		}else if("刪除".equals(deleteBtn)) { //呼叫刪除的方法
			DeleteData deleteData = new DeleteData();
			MemberVo member = deleteData.delete(memberVo);
			System.out.println("member :"+ member);
			
		}else if("列表".equals(listBtn)) { //呼叫顯示所有資料的方法
			
		};
		
		request.setAttribute("id" , id);
		request.setAttribute("phone" , phone);
		request.setAttribute("name" , name);
		request.setAttribute("address" , address);
		request.setAttribute("note" , note);
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
		return null;
		
	}

}