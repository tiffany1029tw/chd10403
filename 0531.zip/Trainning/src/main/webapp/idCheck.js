
		function idCheck() {
			
            var id = document.getElementById("id").value;
            var msg = document.createElement('output');

            idMsg.innerHTML = "";

            if (id.length == 10 && id.match(/^[A-Z][1-2][0-9]{7}[0-9]{1}/)) {
                validateLocalId(id); //檢測個人身分證類別及檢碼 
                //event.preventDefault(); 阻止表單提交

            }else{
				msg.textContent = "輸入格式有誤";
            	idMsg.appendChild(msg);
			};
        }

        //----身分證檢查
        function validateLocalId(id) { 

            var map = new Map(); //map物件包含key,value
            var idChar = id.split(''); //把id拆解 為取得ID的第一位英文字

            var idMsg = document.getElementById("idMsg");
            
            map.set("A" , calculate("10")); //首個英文字對應的數字
            map.set("B" , calculate("11"));
            map.set("C" , calculate("12"));
            map.set("D" , calculate("13"));
            map.set("E" , calculate("14"));
            map.set("F" , calculate("15"));
            map.set("G" , calculate("16"));
            map.set("H" , calculate("17"));
            map.set("I" , calculate("34"));
            map.set("J" , calculate("18"));
            map.set("K" , calculate("19"));
            map.set("L" , calculate("20"));
            map.set("M" , calculate("21"));
            map.set("N" , calculate("22"));
            map.set("O" , calculate("35"));
            map.set("P" , calculate("23"));
            map.set("Q" , calculate("24"));
            map.set("R" , calculate("25"));
            map.set("S" , calculate("26"));
            map.set("T" , calculate("27"));
            map.set("U" , calculate("28"));
            map.set("V" , calculate("29"));
            map.set("W" , calculate("32"));
            map.set("X" , calculate("30"));
            map.set("Y" , calculate("31"));
            map.set("Z" , calculate("33"));
            
            var idNumCal = (idChar[1]*8)+(idChar[2]*7)+(idChar[3]*6)+(idChar[4]*5)+(idChar[5]*4)+(idChar[6]*3)+(idChar[7]*2)+(idChar[8]*1);
            var lastNum = 10 - ((map.get(idChar[0]) + idNumCal)%10);
            console.log(lastNum);
            
            var msg = document.createElement('output');
            if (idChar[9] != (lastNum%10)) {

                msg.textContent = "身份證字號檢碼不符";
                idMsg.appendChild(msg);

            }else{

                msg.textContent = "身份證正確";
                idMsg.appendChild(msg);

            };

        }

        //計算ID第一位英文字母數字總和
        function calculate(numberStr) { 
            var numChar = numberStr.split(''); //數字切開抓十位跟個位
            return parseInt(numChar[0]) + parseInt(numChar[1])*9; //十位數 + 個位數*9
        }/**
 * 
 */