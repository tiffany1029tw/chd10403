package test;

import java.sql.Connection;

import model.DeleteData;
import model.InsertData;
import model.ReadData;
import model.UpdateData;
import model.vo.MemberVo;
import util.SQLConnect;

public class Test {

	public static void main(String[] args) {
		
		//要呼叫該類別的方法時 需要先創建該類別的實體物件後才可呼叫
		ReadData readData = new ReadData();
		InsertData insertData = new InsertData();
		UpdateData updateData = new UpdateData();
		DeleteData deleteData = new DeleteData();
		MemberVo memberVo = new MemberVo();
		
		SQLConnect conn = new SQLConnect();
		Connection dbcon = conn.getConnection();	
		
		memberVo.setId("F222552222");
		memberVo.setPhone("0900000000");
		memberVo.setName("江小姐");
		memberVo.setAddress("汐止");
		memberVo.setNote("貓咪");
		
		//MemberVo member = readData.select(memberVo);
		MemberVo member = insertData.insert(memberVo);
		//MemberVo member = updateData.update(memberVo);
		//MemberVo member = deleteData.delete(memberVo);
		System.out.println("member : " + member);
		
	}
}
