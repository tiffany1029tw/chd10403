package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.vo.MemberVo;
import model.ReadData;
import model.InsertData;
import model.UpdateData;
import model.DeleteData;
import model.ListData;

@WebServlet("/GetParam")
public class GetParam extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("UTF-8"); //解決中文亂碼
		this.getParam(request, response);
		
	}
	
	public String getParam(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("id");
		String phone = request.getParameter("phone");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String note = request.getParameter("note");
		String button = request.getParameter("button");
		
		MemberVo memberVo = new MemberVo();
		memberVo.setId(id);
		memberVo.setName(name);
		memberVo.setPhone(phone);
		memberVo.setAddress(address);
		memberVo.setNote(note);
		
		List<MemberVo> resultList = new ArrayList<>();
		MemberVo member = null;
		ArrayList<MemberVo> rsList = null;
		
		if("readBtn".equals(button)) { //呼叫查詢的方法
			ReadData readData = new ReadData();
			member = readData.select(memberVo);
			resultList.add(member);

			System.out.println(member.toString());
			System.out.println(resultList.toString());
			
		}else if("insertBtn".equals(button)) { //呼叫新增的方法
			InsertData insertData = new InsertData();
			member = insertData.insert(memberVo);
			resultList.add(member);
						
		}else if("updateBtn".equals(button)) { //呼叫修改的方法
			UpdateData updateData = new UpdateData();
			member = updateData.update(memberVo);
			resultList.add(member);
		
		}else if("deleteBtn".equals(button)) { //呼叫刪除的方法
			DeleteData deleteData = new DeleteData();
			member = deleteData.delete(memberVo);
			resultList.add(member);
			
		}else if("listBtn".equals(button)) { //呼叫顯示所有資料的方法
			ListData listData = new ListData();
			rsList = listData.list(memberVo);
			resultList.addAll(rsList); //加入全部元素
		};
		
		request.setAttribute("member" , member); //member物件
		request.setAttribute("rsList" , rsList);
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
		return null;
		
	}

}