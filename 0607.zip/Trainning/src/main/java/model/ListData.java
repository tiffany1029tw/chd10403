package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.vo.MemberVo;
import util.SQLConnect;

public class ListData {

	public ArrayList<MemberVo> list(MemberVo memberVo) {

		ArrayList<MemberVo> rsList = new ArrayList<MemberVo>(); //放member物件的list
		SQLConnect conn = new SQLConnect();
		Connection dbcon = conn.getConnection();

		try {

			// 建立SQL指令對象
			PreparedStatement ps = dbcon.prepareStatement("SELECT * FROM dbo.table_3");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				MemberVo member = new MemberVo(); //new一個MemberVo的實體
					
				member.setId(rs.getString("id"));
				member.setPhone(rs.getString("phone"));
				member.setName(rs.getString("name"));
				member.setAddress(rs.getString("address"));
				member.setNote(rs.getString("note"));
				
				rsList.add(member);
				
				System.out.println(rs.getString("id")+"\t"+rs.getString("phone")+"\t"+rs.getString("name")+"\t"+rs.getString("address")+"\t"+rs.getString("note")+"\t");
				System.out.println("資料列表成功");
				
			}
			
			// 關閉物件連接
			ps.close();

			// 關閉資料庫連接
			dbcon.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rsList;
	}
}