package db ;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CreateDb {

	public static void main(String[] args) {
		
		String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String dburl = "jdbc:sqlserver://172.16.45.213:1433;DatabaseName=kk_testDB;encrypt=false";
		String userName = "sqlap";
		String userPwd = "Ubot@1234";
		
		try {
			Class.forName(driverName); //載入驅動
			System.out.println("連線成功");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("驅動程式載入失敗");
		}
	
		try {
			Connection dbcon = DriverManager.getConnection(dburl,userName,userPwd); //連線資料庫
			System.out.println("資料庫連線成功");
			
			String sql = "CREATE TABLE test(id char(10), phone nchar(10))"; //SQL語法 新建表 欄位名稱/資料型別
		    PreparedStatement ps = dbcon.prepareStatement(sql);
		    ps.executeUpdate(); //執行
		    System.out.println("表格新增成功");
			
			//關閉物件連接
		    ps.close();
			
			//關閉資料庫連接
			dbcon.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("連線失敗");
			
		}
	}
}