package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtil {

	//DB connection
	public Connection getConnection() { 
		
		String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String dburl = "jdbc:sqlserver://172.16.45.213:1433;DatabaseName=kk_testDB;encrypt=false";
		String userName = "sqlap";
		String userPwd = "Ubot@1234";
		
		try {
			Class.forName(driverName);
			System.out.println("連線成功!!!");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("驅動程式載入失敗");
		}
	
		try {
			Connection dbcon = DriverManager.getConnection(dburl,userName,userPwd);
			System.out.println("資料庫連線成功！");
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("連線失敗");
			
		}
		
	}
}
