package db ;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReadDb {

	public static void main(String[] args) {
		
		String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String dburl = "jdbc:sqlserver://172.16.45.213:1433;DatabaseName=kk_testDB;encrypt=false";
		String userName = "sqlap";
		String userPwd = "Ubot@1234";
		
		try {
			Class.forName(driverName);
			System.out.println("連線成功");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("驅動程式載入失敗");
		}
	
		try {
			Connection dbcon = DriverManager.getConnection(dburl,userName,userPwd); //載入資料庫
			System.out.println("資料庫連線成功");
			
			//建立SQL指令對象
			Statement stmt = dbcon.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM dbo.table_3");
			
			//循環讀出每個數據
			while(rs.next()) {
				System.out.println(rs.getString("id")+"\t" +rs.getString("phone")+"\t"
				+rs.getString("name")+"\t"+rs.getString("address")+"\t"+rs.getString("note")+"\t");
			}
			
			//關閉物件連接
			stmt.close();
			
			//關閉資料庫連接
			dbcon.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("連線失敗");
			
		}
	}
}