package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class memberDao {

	//Member insert
	public boolean insertMember(MemberVo vo) {
		
		DBUtil dbutil = new DBUtil();
		Connection conn = dbutil.getConnection();
		
		System.out.println("資料庫連線成功！");
		
		//建立SQL指令對象
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select id, phone, name, address, note from dbo.table_3");
		
		//循環讀出每個數據
		while(rs.next()) {
			System.out.println(rs.getString("id")+"\t" +rs.getString("phone")+"\t"+rs.getString("name")+"\t"+rs.getString("address")+"\t"+rs.getString("note")+"\t");
		}
		
		//關閉物件連接
		stmt.close();
		
		//關閉資料庫連接
		conn.close();
	}
}
