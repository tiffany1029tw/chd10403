package model ;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteData {

	public static void main(String[] args) {
		
		String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String dburl = "jdbc:sqlserver://172.16.45.213:1433;DatabaseName=kk_testDB;encrypt=false";
		String userName = "sqlap";
		String userPwd = "Ubot@1234";
		
		try {
			Class.forName(driverName); //載入驅動
			System.out.println("連線成功");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("驅動程式載入失敗");
		}
		
		try {
			Connection dbcon = DriverManager.getConnection(dburl,userName,userPwd); //連線資料庫
			System.out.println("資料庫連線成功");
			
			String sql = "DELETE FROM dbo.table_3 WHERE id= ?"; //SQL語法
		    PreparedStatement ps = dbcon.prepareStatement(sql);
		    ps.setString(1, "F225377381");
		    ps.executeUpdate(); //執行
		    System.out.println("資料刪除成功");
			
			//關閉物件連接
		    ps.close();
			
			//關閉資料庫連接
			dbcon.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("連線失敗");
			
		}
		
	}
	
}